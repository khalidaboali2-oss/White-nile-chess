# White Nile Chess Academy — V4 repair build

Owner / author: **Khalid Ahmed Mostafa Yousif**

This build upgrades the original MVP foundation with a real server-authoritative chess API, account/authentication scaffolding, persistent JSON storage, live WebSocket state, clock/increment handling, PGN export, draw offers, resignation, blindfold and simultaneous-game endpoints, player profiles/ratings, friends/following, messages, challenges, tournament systems including **Khalid System**, tournament standings, and fair-play review scaffolding.

## Tournament systems
- Swiss
- Round Robin
- Knockout
- Arena
- Teams
- **Khalid System** (additional independent system)

Khalid System records elimination order and ranks eliminated players by exit order while the final survivor remains champion. A confirmed cheating result cancels the Khalid event and schedules a full restart after 24 hours.

## Chess/game options
- Bullet 1+0 and 2+0
- Blitz, Rapid, Classical
- Chess960 option in the client/API
- Blindfold: board remains visible while pieces are hidden
- Simultaneous play: host versus 2–10 parallel opponents
- Draw offer/acceptance, resignation, automatic game-over rules through chess.js
- PGN sharing and game-link sharing
- Accuracy display field ready for engine/statistics integration

## UI requirements implemented
- “White Nile Chess Academy” is above the board, outside the squares.
- Opponent name is above the board; player name is below.
- Board themes and coordinate toggle.
- Full-screen bridge plus normal mode.
- Tournament return button.
- Profile sections for ratings, friends, messages, and games.
- Direct and link challenges.

## Android
`MainActivity` exposes `AndroidBridge.shareText()` and `AndroidBridge.fullscreen()` to the web UI. Cleartext HTTP is enabled for local development; use HTTPS in production.

## Backend
The backend stores users, reports, tournaments, messages, friendships, ratings and bans in `backend/data/store.json`. This is intentionally a lightweight MVP persistence layer; production deployment should replace it with PostgreSQL/Redis and add HTTPS, rate limiting, secure refresh tokens, admin authorization, audit logs and a production anti-cheat service.

## Run backend
```bash
cd backend
npm install
npm start
```

Set `PORT` and `DATA_DIR` as needed.

## Important production note
Anti-cheat is implemented as a review/penalty workflow, not as an automatic “engine certainty” detector. Confirmed cases can ban the account email and correct results. Human/admin review should remain mandatory to reduce false positives.

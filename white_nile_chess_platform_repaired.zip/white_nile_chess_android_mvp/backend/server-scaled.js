const express=require("express");
const http=require("http");
const cors=require("cors");
const {WebSocketServer}=require("ws");
const Redis=require("ioredis");
const {Chess}=require("chess.js");
const crypto=require("crypto");

const app=express(); app.use(cors()); app.use(express.json());
const server=http.createServer(app);
const wss=new WebSocketServer({server,path:"/ws"});
const redis=new Redis(process.env.REDIS_URL||"redis://localhost:6379");
const sub=new Redis(process.env.REDIS_URL||"redis://localhost:6379");
const localSockets=new Map();

const id=p=>p+"_"+crypto.randomBytes(7).toString("hex");
const key=id=>`game:${id}`;

app.get("/health",async(req,res)=>res.json({ok:true,service:"white-nile-chess-scaled",instance:process.env.HOSTNAME||"local"}));

app.post("/games",async(req,res)=>{
  const gameId=id("game");
  const game={id:gameId,mode:req.body.mode==="unrated"?"unrated":"rated",time:req.body.time||"10+0",
    status:"waiting",players:[],fen:new Chess().fen(),createdAt:Date.now()};
  await redis.set(key(gameId),JSON.stringify(game),"EX",86400);
  res.status(201).json(game);
});

app.get("/games/:id",async(req,res)=>{
  const raw=await redis.get(key(req.params.id));
  if(!raw)return res.status(404).json({error:"not_found"});
  res.json(JSON.parse(raw));
});

app.post("/games/:id/join",async(req,res)=>{
  const k=key(req.params.id),raw=await redis.get(k);
  if(!raw)return res.status(404).json({error:"not_found"});
  const g=JSON.parse(raw);
  if(g.players.length>=2)return res.status(409).json({error:"full"});
  g.players.push({id:req.body.playerId||id("player"),color:g.players.length?"black":"white"});
  if(g.players.length===2)g.status="playing";
  await redis.set(k,JSON.stringify(g),"EX",86400);
  await redis.publish(`game:${g.id}`,JSON.stringify({type:"state",game:g}));
  res.json(g);
});

wss.on("connection",(ws,req)=>{
  const u=new URL(req.url,"http://localhost");
  const gameId=u.searchParams.get("gameId");
  if(!gameId){ws.close(1008,"gameId required");return;}
  if(!localSockets.has(gameId))localSockets.set(gameId,new Set());
  localSockets.get(gameId).add(ws);
  ws.on("close",()=>localSockets.get(gameId)?.delete(ws));
});

sub.psubscribe("game:*");
sub.on("pmessage",(pattern,channel,message)=>{
  const set=localSockets.get(channel.slice(5)); if(!set)return;
  for(const ws of set)if(ws.readyState===1)ws.send(message);
});

const port=process.env.PORT||8080;
server.listen(port,()=>console.log("scaled node listening",port));

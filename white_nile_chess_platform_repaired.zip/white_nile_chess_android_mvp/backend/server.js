const express = require('express');
const http = require('http');
const cors = require('cors');
const { WebSocketServer } = require('ws');
const { Chess } = require('chess.js');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json({limit:'1mb'}));

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname,'data');
fs.mkdirSync(DATA_DIR,{recursive:true});
const DB_FILE = path.join(DATA_DIR,'store.json');
const now=()=>new Date().toISOString();
const id=p=>`${p}_${crypto.randomBytes(8).toString('hex')}`;
const hash=(v,salt=crypto.randomBytes(16).toString('hex'))=>({salt,hash:crypto.scryptSync(v,salt,64).toString('hex')});
const verify=(v,h)=>crypto.timingSafeEqual(Buffer.from(h.hash,'hex'),crypto.scryptSync(v,h.salt,64));
let db={users:[],games:[],tournaments:[],messages:[],reports:[],challenges:[],friendships:[],ratings:[],bans:[],events:[]};
try{if(fs.existsSync(DB_FILE))db=JSON.parse(fs.readFileSync(DB_FILE,'utf8'));}catch(e){}
function save(){fs.writeFileSync(DB_FILE,JSON.stringify(db,null,2));}
const sessions=new Map(); const sockets=new Map(); const games=new Map();
function persistGame(g){ const x={id:g.id,type:g.type,mode:g.mode,timeControl:g.timeControl,status:g.status,players:g.players,moves:g.moves,createdAt:g.createdAt,endedAt:g.endedAt,reason:g.reason,clocks:g.clocks}; const i=db.games.findIndex(v=>v.id===g.id); if(i<0)db.games.push(x);else db.games[i]=x; save(); }
function restoreGames(){ for(const x of db.games.filter(v=>v.status==='playing'||v.status==='waiting')){ try{const c=new Chess(); for(const san of x.moves||[]) c.move(san); games.set(x.id,{...x,chess:c,lastTick:Date.now()});}catch(e){} } }

const SYSTEMS=['swiss','round_robin','knockout','arena','teams','khalid'];
const RATING_TYPES=['bullet','blitz','rapid','classical','chess960'];
const TIMES={'1+0':60,'2+0':120,'3+0':180,'3+2':180,'5+0':300,'10+0':600,'15+10':900,'20+0':1200,'30+0':1800};

app.get('/health',(q,r)=>r.json({ok:true,service:'white-nile-chess',version:'2.0.0',academy:'White Nile Chess Academy',owner:'Khalid Ahmed Mostafa Yousif'}));
function auth(req,res,next){const token=(req.headers.authorization||'').replace(/^Bearer /,''); const u=sessions.get(token); if(!u)return res.status(401).json({error:'unauthorized'}); req.user=u; next();}
function publicUser(u){return {id:u.id,username:u.username,name:u.name,email:u.email,createdAt:u.createdAt};}
function banned(email){return db.bans.some(b=>b.email===email.toLowerCase());}

app.post('/auth/register',(req,res)=>{const {email,password,username,name}=req.body||{}; if(!email||!password||!username)return res.status(400).json({error:'email_password_username_required'}); const e=email.toLowerCase(); if(banned(e))return res.status(403).json({error:'email_banned'}); if(db.users.some(u=>u.email===e||u.username.toLowerCase()===username.toLowerCase()))return res.status(409).json({error:'already_exists'}); const u={id:id('user'),email:e,username,name:name||username,pass:hash(password),createdAt:now()}; db.users.push(u); save(); const token=id('sess'); sessions.set(token,u.id); res.status(201).json({token,user:publicUser(u)});});
app.post('/auth/login',(req,res)=>{const {email,password}=req.body||{};const u=db.users.find(x=>x.email===String(email||'').toLowerCase());if(!u||!verify(password||'',u.pass))return res.status(401).json({error:'invalid_credentials'});const token=id('sess');sessions.set(token,u.id);res.json({token,user:publicUser(u)});});
app.get('/auth/me',auth,(req,res)=>res.json({user:publicUser(db.users.find(u=>u.id===req.user))}));

function gamePublic(g){return {id:g.id,type:g.type,mode:g.mode,timeControl:g.timeControl,status:g.status,players:g.players.map(p=>({id:p.id,name:p.name,color:p.color})),fen:g.chess.fen(),moves:g.moves,createdAt:g.createdAt,endedAt:g.endedAt,reason:g.reason,pgn:g.chess.pgn(),whiteTime:g.clocks.white,blackTime:g.clocks.black};}
function setupGame(body,creator){const tc=body.timeControl||'10+0'; if(!TIMES[tc])throw Error('invalid_time'); const g={id:id('game'),type:body.type||'standard',mode:body.mode==='unrated'?'unrated':'rated',timeControl:tc,status:'waiting',players:[{id:creator.id,name:creator.name,color:'white'}],chess:new Chess(),moves:[],createdAt:now(),clocks:{white:TIMES[tc],black:TIMES[tc]},lastTick:null};games.set(g.id,g);persistGame(g);return g;}
app.post('/games',auth,(req,res)=>{try{const g=setupGame(req.body,db.users.find(u=>u.id===req.user));res.status(201).json(gamePublic(g));}catch(e){res.status(400).json({error:e.message});}});
app.get('/games/:id',(req,res)=>{const g=games.get(req.params.id);if(!g)return res.status(404).json({error:'not_found'});res.json(gamePublic(g));});
app.post('/games/:id/join',auth,(req,res)=>{const g=games.get(req.params.id);if(!g)return res.status(404).json({error:'not_found'});if(g.players.length>=2)return res.status(409).json({error:'full'});const u=db.users.find(x=>x.id===req.user);g.players.push({id:u.id,name:u.name,color:'black'});g.status='playing';g.lastTick=Date.now();persistGame(g);broadcast(g.id,{type:'state',game:gamePublic(g)});res.json(gamePublic(g));});
function tick(g){if(g.status!=='playing'||!g.lastTick)return;const dt=Math.max(0,(Date.now()-g.lastTick)/1000);const side=g.chess.turn()==='w'?'white':'black';g.clocks[side]-=dt;g.lastTick=Date.now();if(g.clocks[side]<=0){g.clocks[side]=0;g.status='finished';g.reason='timeout';g.endedAt=now();persistGame(g);}}
app.post('/games/:id/move',auth,(req,res)=>{const g=games.get(req.params.id);if(!g)return res.status(404).json({error:'not_found'});if(g.status!=='playing')return res.status(409).json({error:'not_playing'});const p=g.players.find(x=>x.id===req.user);if(!p||p.color!==(g.chess.turn()==='w'?'white':'black'))return res.status(403).json({error:'not_your_turn'});tick(g);try{const m=g.chess.move({from:req.body.from,to:req.body.to,promotion:req.body.promotion||'q'});g.moves.push(m.san);const inc=Number((g.timeControl.split('+')[1]||0));g.clocks[p.color]+=inc;g.lastTick=Date.now();if(g.chess.isGameOver()){g.status='finished';g.endedAt=now();g.reason=g.chess.isCheckmate()?'checkmate':g.chess.isStalemate()?'stalemate':g.chess.isThreefoldRepetition()?'threefold':g.chess.isDraw()?'draw':'game_over';}persistGame(g);broadcast(g.id,{type:'move',move:m,game:gamePublic(g)});res.json({ok:true,game:gamePublic(g)});}catch(e){res.status(400).json({error:'illegal_move'});}});
app.post('/games/:id/draw-offer',auth,(req,res)=>{const g=games.get(req.params.id);if(!g||g.status!=='playing')return res.status(409).json({error:'not_playing'});g.drawOffer=req.user;persistGame(g);broadcast(g.id,{type:'draw_offer',from:req.user});res.json({ok:true});});
app.post('/games/:id/draw-accept',auth,(req,res)=>{const g=games.get(req.params.id);if(!g||!g.drawOffer)return res.status(409).json({error:'no_offer'});g.status='finished';g.reason='agreement';g.endedAt=now();persistGame(g);broadcast(g.id,{type:'game_end',game:gamePublic(g)});res.json({ok:true,game:gamePublic(g)});});
app.post('/games/:id/resign',auth,(req,res)=>{const g=games.get(req.params.id);if(!g||g.status!=='playing')return res.status(409).json({error:'not_playing'});g.status='finished';g.reason='resignation';g.endedAt=now();persistGame(g);broadcast(g.id,{type:'game_end',game:gamePublic(g)});res.json({ok:true,game:gamePublic(g)});});
app.get('/games/:id/pgn',(req,res)=>{const g=games.get(req.params.id);if(!g)return res.status(404).json({error:'not_found'});res.type('text/plain').send(g.chess.pgn());});

// Simultaneous play: one host against 2..10 opponents, each opponent has a parallel board.
app.post('/simuls',auth,(req,res)=>{const n=Math.min(10,Math.max(2,Number(req.body.opponents||2)));const host=db.users.find(u=>u.id===req.user);const ids=[];for(let i=0;i<n;i++){const g=setupGame({type:'simul',mode:req.body.mode,timeControl:req.body.timeControl||'5+0'},host);g.simulHost=host.id;ids.push(g.id);}res.status(201).json({type:'simul',opponents:n,gameIds:ids});});

app.post('/blindfold/games',auth,(req,res)=>{const g=setupGame({type:'blindfold',mode:req.body.mode,timeControl:req.body.timeControl||'5+0'},db.users.find(u=>u.id===req.user));res.status(201).json({...gamePublic(g),hidePieces:true});});

function rating(userId,type){let r=db.ratings.find(x=>x.userId===userId&&x.type===type);if(!r){r={userId,type,rating:1200,games:0,wins:0,losses:0,draws:0};db.ratings.push(r);}return r;}
app.get('/players/:id/profile',(req,res)=>{const u=db.users.find(x=>x.id===req.params.id);if(!u)return res.status(404).json({error:'not_found'});res.json({user:publicUser(u),ratings:RATING_TYPES.map(t=>rating(u.id,t)),games:db.events.filter(e=>e.type==='game'&&(e.white===u.id||e.black===u.id)).slice(-100)});});
app.get('/players/search',auth,(req,res)=>{const q=String(req.query.q||'').toLowerCase();res.json(db.users.filter(u=>u.username.toLowerCase().includes(q)||u.name.toLowerCase().includes(q)).slice(0,50).map(publicUser));});
app.post('/friends/:id/follow',auth,(req,res)=>{if(req.params.id===req.user)return res.status(400).json({error:'self'});if(!db.friendships.some(f=>f.a===req.user&&f.b===req.params.id))db.friendships.push({a:req.user,b:req.params.id,createdAt:now()});save();res.json({ok:true});});
app.get('/friends',auth,(req,res)=>res.json(db.friendships.filter(f=>f.a===req.user).map(f=>publicUser(db.users.find(u=>u.id===f.b))).filter(Boolean)));
app.post('/messages',auth,(req,res)=>{const m={id:id('msg'),from:req.user,to:req.body.to,text:String(req.body.text||'').slice(0,2000),createdAt:now()};db.messages.push(m);save();res.status(201).json(m);});
app.get('/messages',auth,(req,res)=>res.json(db.messages.filter(m=>m.from===req.user||m.to===req.user).slice(-200)));
app.post('/challenges',auth,(req,res)=>{const c={id:id('challenge'),from:req.user,to:req.body.to,timeControl:req.body.timeControl||'10+0',variant:req.body.variant||'standard',via:req.body.via||'direct',status:'pending',createdAt:now()};db.challenges.push(c);save();res.status(201).json(c);});
app.post('/challenges/:id/accept',auth,(req,res)=>{const c=db.challenges.find(x=>x.id===req.params.id&&x.to===req.user);if(!c)return res.status(404).json({error:'not_found'});c.status='accepted';const host=db.users.find(u=>u.id===c.from);const g=setupGame({mode:'rated',timeControl:c.timeControl,type:c.variant},host);g.challengeId=c.id;g.players.push({id:req.user,name:db.users.find(u=>u.id===req.user).name,color:'black'});g.status='playing';save();res.json(gamePublic(g));});

app.post('/tournaments',(req,res)=>{const system=String(req.body.system||'swiss').toLowerCase();if(!SYSTEMS.includes(system))return res.status(400).json({error:'invalid_system',systems:SYSTEMS});const t={id:id('tournament'),name:req.body.name||'White Nile Online',system,rated:!!req.body.rated,rounds:Number(req.body.rounds||7),status:'registration',players:[],results:[],createdAt:now(),restartAt:null};db.tournaments.push(t);save();res.status(201).json(t);});
app.get('/tournaments',(req,res)=>res.json(db.tournaments));
app.get('/tournaments/:id',(req,res)=>{const t=db.tournaments.find(x=>x.id===req.params.id);if(!t)return res.status(404).json({error:'not_found'});res.json(t);});
app.post('/tournaments/:id/register',(req,res)=>{const t=db.tournaments.find(x=>x.id===req.params.id);if(!t)return res.status(404).json({error:'not_found'});if(!t.players.some(x=>x.id===req.body.playerId))t.players.push({id:req.body.playerId,name:req.body.name||'Player',rating:Number(req.body.rating||1200),score:0,eliminated:false,eliminationOrder:null});save();res.json(t);});
app.post('/tournaments/:id/start',(req,res)=>{const t=db.tournaments.find(x=>x.id===req.params.id);if(!t)return res.status(404).json({error:'not_found'});if(t.players.length<2)return res.status(400).json({error:'not_enough_players'});t.status='running';t.startedAt=now();if(t.system==='khalid')t.players.forEach(p=>{p.eliminated=false;p.eliminationOrder=null;});save();res.json(t);});
app.post('/tournaments/:id/result',(req,res)=>{const t=db.tournaments.find(x=>x.id===req.params.id);if(!t)return res.status(404).json({error:'not_found'});const {winnerId,loserId,cheated}=req.body;const w=t.players.find(p=>p.id===winnerId),l=t.players.find(p=>p.id===loserId);if(!w||!l)return res.status(400).json({error:'players_not_found'});if(cheated){l.eliminated=true;l.cheat=true;if(t.system==='khalid'){t.status='cancelled';t.restartAt=new Date(Date.now()+86400000).toISOString();t.restartReason='confirmed_cheating';}t.results.push({winnerId,loserId,cheated:true,correctedWinnerId:loserId,createdAt:now()});}else{w.score+=1;t.results.push({winnerId,loserId,cheated:false,createdAt:now()});if(t.system==='khalid'){l.eliminated=true;l.eliminationOrder=t.players.filter(p=>p.eliminationOrder).length+1;}}save();res.json(t);});
app.get('/tournaments/:id/standings',(req,res)=>{const t=db.tournaments.find(x=>x.id===req.params.id);if(!t)return res.status(404).json({error:'not_found'});let ps=[...t.players];if(t.system==='khalid')ps.sort((a,b)=>{if(a.eliminated!==b.eliminated)return a.eliminated?1:-1;if(a.eliminationOrder&&b.eliminationOrder)return b.eliminationOrder-a.eliminationOrder;return b.score-a.score;});else ps.sort((a,b)=>b.score-a.score||b.rating-a.rating);res.json({tournament:t,standings:ps});});

app.post('/reports',auth,(req,res)=>{const r={id:id('report'),gameId:req.body.gameId,reporterId:req.user,reportedId:req.body.reportedId,type:req.body.type||'fair_play',details:req.body.details||'',status:'review',createdAt:now()};db.reports.push(r);save();res.status(201).json(r);});
app.post('/fairplay/:reportId/confirm',(req,res)=>{const r=db.reports.find(x=>x.id===req.params.reportId);if(!r)return res.status(404).json({error:'not_found'});r.status='confirmed';const u=db.users.find(x=>x.id===r.reportedId);if(u){db.bans.push({email:u.email,reason:'confirmed_cheating',createdAt:now()});}const game=db.events.find(e=>e.id===r.gameId);if(game){game.corrected=true;game.winner=r.reporterId;}save();res.json({ok:true,report:r});});

const server=http.createServer(app);const wss=new WebSocketServer({server,path:'/ws'});
wss.on('connection',(ws,req)=>{const gameId=new URL(req.url,'http://localhost').searchParams.get('gameId');if(!gameId||!games.has(gameId))return ws.close();if(!sockets.has(gameId))sockets.set(gameId,new Set());sockets.get(gameId).add(ws);ws.send(JSON.stringify({type:'state',game:gamePublic(games.get(gameId))}));ws.on('close',()=>sockets.get(gameId)?.delete(ws));});
function broadcast(gameId,payload){for(const ws of sockets.get(gameId)||[])if(ws.readyState===1)ws.send(JSON.stringify(payload));}
setInterval(()=>{for(const g of games.values())if(g.status==='playing'){tick(g);if(g.status==='finished')broadcast(g.id,{type:'game_end',game:gamePublic(g)});}},1000);
restoreGames();
const port=process.env.PORT||8080;server.listen(port,()=>console.log(`White Nile Chess server listening on ${port}`));

# White Nile Chess — Android MVP

Android project wrapper for the White Nile Chess Academy UI.

Build:
1. Open this folder in Android Studio.
2. Sync Gradle.
3. Run on an Android 8+ device/emulator.
4. Build > Generate Signed App Bundle to create the Google Play AAB.

Important:
- This build is an Android MVP client around the designed UI.
- The real online service must be connected to `backend/API_SPEC.md`.
- Do not publish a production APK/AAB until backend authentication, legal server-side chess validation, database, WebSocket service, rating, tournament engine, fair-play review, privacy policy and Play Console requirements are completed.
- The provided personal administrative email is not embedded as a public contact.
